<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.meal-resource.pages.manage-meals' => 'App\\Filament\\Resources\\MealResource\\Pages\\ManageMeals',
    'app.filament.resources.reservation-resource.pages.create-reservation' => 'App\\Filament\\Resources\\ReservationResource\\Pages\\CreateReservation',
    'app.filament.resources.reservation-resource.pages.edit-reservation' => 'App\\Filament\\Resources\\ReservationResource\\Pages\\EditReservation',
    'app.filament.resources.reservation-resource.pages.list-reservations' => 'App\\Filament\\Resources\\ReservationResource\\Pages\\ListReservations',
    'app.filament.resources.room-resource.pages.create-room' => 'App\\Filament\\Resources\\RoomResource\\Pages\\CreateRoom',
    'app.filament.resources.room-resource.pages.edit-room' => 'App\\Filament\\Resources\\RoomResource\\Pages\\EditRoom',
    'app.filament.resources.room-resource.pages.list-rooms' => 'App\\Filament\\Resources\\RoomResource\\Pages\\ListRooms',
    'app.filament.resources.room-resource.pages.view-room' => 'App\\Filament\\Resources\\RoomResource\\Pages\\ViewRoom',
    'app.filament.resources.season-resource.pages.create-season' => 'App\\Filament\\Resources\\SeasonResource\\Pages\\CreateSeason',
    'app.filament.resources.season-resource.pages.edit-season' => 'App\\Filament\\Resources\\SeasonResource\\Pages\\EditSeason',
    'app.filament.resources.season-resource.pages.list-seasons' => 'App\\Filament\\Resources\\SeasonResource\\Pages\\ListSeasons',
    'app.filament.resources.season-resource.relation-managers.dates-relation-manager' => 'App\\Filament\\Resources\\SeasonResource\\RelationManagers\\DatesRelationManager',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\Projects\\ihg\\intercontinental\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\Projects\\ihg\\intercontinental\\app\\Filament\\Resources\\MealResource.php' => 'App\\Filament\\Resources\\MealResource',
    'D:\\Projects\\ihg\\intercontinental\\app\\Filament\\Resources\\ReservationResource.php' => 'App\\Filament\\Resources\\ReservationResource',
    'D:\\Projects\\ihg\\intercontinental\\app\\Filament\\Resources\\RoomResource.php' => 'App\\Filament\\Resources\\RoomResource',
    'D:\\Projects\\ihg\\intercontinental\\app\\Filament\\Resources\\SeasonResource.php' => 'App\\Filament\\Resources\\SeasonResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\Projects\\ihg\\intercontinental\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\Projects\\ihg\\intercontinental\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);